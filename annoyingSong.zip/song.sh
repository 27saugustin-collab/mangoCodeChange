#!/bin/bash

# Check if a file path was provided
if [ -z "$1" ]; then
    echo "Usage: ./play.sh <path_to_audio_file>"
    exit 1
fi

FILE=$1

echo "Playing: $FILE"

# Detect OS and use the appropriate player
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS built-in player
    afplay "$FILE"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux: tries common players in order of reliability
    if command -v paplay >/dev/null; then
        paplay "$FILE"
    elif command -v ffplay >/dev/null; then
        ffplay -nodisp -autoexit "$FILE"
    else
        echo "No supported player found. Install 'pulseaudio-utils' or 'ffmpeg'."
    fi
fi
